<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-widget-activity-count.php
	Description: Widget module class for activity count plugin


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

class qa_nimeyo_category_filter
{
	public function allow_template($template)
	{
		return true;
	}

	public function allow_region($region)
	{
		return ($region=='side');
	}

	public function output_widget($region, $place, $themeobject, $template, $request, $qa_content)
	{
		
		require_once QA_INCLUDE_DIR.'db/selects.php';


		$categoryid=qa_post_text('categoryid');
		if (!strlen($categoryid))
			$categoryid=null;

		list($fullcategory, $categories)=qa_db_select_with_pending(
			qa_db_full_category_selectspec($categoryid, true),
			qa_db_category_sub_selectspec($categoryid)
		);

	
		echo qa_html(strtr(@$fullcategory['content'], "\r\n", '  ')); // category description

		$themeobject->output('<div class="heading">filter by category</div>
			<div class="content">
				<ul class = "category-list">');
		foreach ($categories as $category) {
			$themeobject->output('<li class="border"> 
									<input id="'.$category['categoryid'].'" type="checkbox">
									<label for="'.$category['categoryid'].'"><span><span></span></span>'.$category['title'].' </label>
								</li>');
		}
			//echo "\n".$category['categoryid'].'/'.$category['title']; // subcategory information


		/*$themeobject->output('<div class="qa-activity-count">');

			
					<li class="border"> 
						<input id="option1" type="checkbox">
						<label for="option1"><span><span></span></span>all categories </label>
					</li>
					<li class="border"> 
						<input id="option2" type="checkbox">
						<label for="option2"><span><span></span></span>category 01  </label>
					</li>
					<li class="border"> 
						<input id="option3" type="checkbox">
						<label for="option3"><span><span></span></span>category 02 </label>
					</li>*/
				$themeobject->output('</ul>
				<a href="#" class = "category-link">View All categories</a>
				<form class="category-form" role="search">
					<div class="input-group search">
						<input type="text" class="form-control" placeholder="Search Categories" name="q">
						<div class="input-group-btn">
							<button class="btn btn-default search-btn" type="submit">
								<i class="glyphicon glyphicon-search"></i>
							</button>
						</div>
					</div>
				</form>
			</div>');	
	}
}
