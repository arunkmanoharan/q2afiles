<?php

if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


function qa_users_sub_nimeyo_navigation()
/*
	Return the sub navigation structure for user listing pages
*/
	{
		if ((!QA_FINAL_EXTERNAL_USERS) && (qa_get_logged_in_level()>=QA_USER_LEVEL_MODERATOR)) {
			return array(
				'users/active' => array(
					'url' => qa_path_html('users/active'),
					'label' => 'ACTIVE',
				),
				'users/blocked' => array(
					'label' => 'INACTIVE',
					'url' => qa_path_html('users/blocked'),
				),
			);

		} else
			return null;
	}
	
	
	function qa_tags_sub_nimeyo_navigation()
/*
	Return the sub navigation structure for user listing pages
*/
	{
			return array(
				'tags/recent' => array(
					'url' => qa_path_html('tags/recent'),
					'label' => 'RECENT',
				),

				'tags/hot' => array(
					'label' => 'HOT',
					'url' => qa_path_html('tags/hot'),
				),

				'tags/name' => array(
					'label' => 'NAME',
					'url' => qa_path_html('tags/name')
				),
			);
	}
	
	function qa_db_popular1_tags_selectspec($start, $count=null, $sort=null, $filter=null)
/*
	Return the selectspec to retrieve the most popular tags. Return $count (if null, a default is used) tags, starting
	from offset $start. The selectspec will produce a sorted array with tags in the key, and counts in the values.
*/
	{
		switch ($sort) {
			case 'recent':
				$selectsort='sortdesc';
				$value =  'wordid';
				break;

			
			case 'name':
				$selectsort='sortasc';
				$value =  'word';
				break;
				
			case 'hot':
				$selectsort='sortdesc';
				$value =  'tagcount';
				break;

			default:
				$selectsort='sortdesc';
				$value =  'tagcount';
				break;
		}
		
		$where = '';
		if($filter) {
			$where = 'word LIKE "%'.$filter.'%" AND';
		}
			
			$count=isset($count) ? $count : QA_DB_RETRIEVE_TAGS;

			return array(
				'columns' => array('word', 'tagcount', 'wordid'),
				'source' => '^words WHERE '.$where.' tagcount>0 ORDER BY tagcount ASC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'word',
				'arrayvalue' => 'tagcount',
				$selectsort => $value,
				//'sortasc' => $sort?$sort:'word',
			);
	}
	

	function qa_db_active_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight', 'loggedin','created'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags!="'.QA_USER_FLAGS_USER_BLOCKED.'" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}
	
	function qa_db_inactive_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight','loggedin','created'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags="'.QA_USER_FLAGS_USER_BLOCKED.'" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}
	
	/* Get the badges for user in users page */
	function badges_users($user_id) {
		
		$result = qa_db_read_all_assoc(
			qa_db_query_sub(
				'SELECT badge_slug as slug, object_id AS oid FROM ^userbadges WHERE user_id=#',
				$user_id
			)
		);
		
		//print_r($result);
		$usr_badges = array();	
		$typed = '';
		if(count($result) > 0) {
			// count badges
			$bin = qa_get_badge_list();
			
			$badges = array();
			
			foreach($result as $info) {
				$slug = $info['slug'];
				$type = $bin[$slug]['type'];
				if(isset($badges[$type][$slug])) $badges[$type][$slug]['count']++;
				else $badges[$type][$slug]['count'] = 1;
				if($info['oid']) $badges[$type][$slug]['oid'][] = $info['oid'];
			}
			
			foreach($badges as $type => $badge) {
				
				$typea = qa_get_badge_type($type);
				$types = $typea['slug'];
				$typed = $typea['name'];
				$usr_badges[$typed] = count($badge);
				//echo '<br>'.$typed;
			}
			
		}
		
		return $usr_badges;
	}
	
	
	function qa_get_user_avatar_html_nimeyo($flags, $email, $handle, $blobid, $width, $height, $size, $padding=false)
	/*
		Return HTML to display for the user's avatar, constrained to $size pixels, with optional $padding to that size
		Pass the user's fields $flags, $email, $handle, and avatar $blobid, $width and $height
	*/
		{
			if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

			require_once QA_INCLUDE_DIR.'app/format.php';

			if (qa_opt('avatar_allow_gravatar') && ($flags & QA_USER_FLAGS_SHOW_GRAVATAR))
				$html=qa_get_gravatar_html($email, $size);
			elseif (qa_opt('avatar_allow_upload') && (($flags & QA_USER_FLAGS_SHOW_AVATAR)) && isset($blobid))
				$html=qa_get_avatar_blob_html($blobid, $width, $height, $size, $padding);
			elseif ( (qa_opt('avatar_allow_gravatar')||qa_opt('avatar_allow_upload')) && qa_opt('avatar_default_show') && strlen(qa_opt('avatar_default_blobid')) )
				$html=qa_get_avatar_blob_html(qa_opt('avatar_default_blobid'), qa_opt('avatar_default_width'), qa_opt('avatar_default_height'), $size, $padding);
			else
				$html=null;

			return (isset($html) && strlen($handle)) ? ('<a href="'.qa_path_html('userdetail/'.$handle).'" class="qa-avatar-link">'.$html.'</a>') : $html;
		}
		
	function qa_user_sub_navigation_nimeyo($handle, $selected, $ismyuser=false)
/*
	Return the sub navigation structure for navigating between the different pages relating to a user
*/
	{
		$navigation=array(
			'profile' => array(
				'label' => qa_lang_html_sub('profile/user_x', qa_html($handle)),
				'url' => qa_path_html('userdetail/'.$handle),
			),

			'account' => array(
				'label' => qa_lang_html('misc/nav_my_details'),
				'url' => qa_path_html('account'),
			),

			'favorites' => array(
				'label' => qa_lang_html('misc/nav_my_favorites'),
				'url' => qa_path_html('favorites'),
			),

			'wall' => array(
				'label' => qa_lang_html('misc/nav_user_wall'),
				'url' => qa_path_html('userdetail/'.$handle.'/wall'),
			),

			'messages' => array(
				'label' => qa_lang_html('misc/nav_user_pms'),
				'url' => qa_path_html('messages'),
			),

			'activity' => array(
				'label' => qa_lang_html('misc/nav_user_activity'),
				'url' => qa_path_html('userdetail/'.$handle.'/activity'),
			),

			'questions' => array(
				'label' => qa_lang_html('misc/nav_user_qs'),
				'url' => qa_path_html('userdetail/'.$handle.'/questions'),
			),

			'answers' => array(
				'label' => qa_lang_html('misc/nav_user_as'),
				'url' => qa_path_html('userdetail/'.$handle.'/answers'),
			),
		);

		if (isset($navigation[$selected]))
			$navigation[$selected]['selected']=true;

		if (QA_FINAL_EXTERNAL_USERS || !qa_opt('allow_user_walls'))
			unset($navigation['wall']);

		if (QA_FINAL_EXTERNAL_USERS || !$ismyuser)
			unset($navigation['account']);

		if (!$ismyuser)
			unset($navigation['favorites']);

		if (QA_FINAL_EXTERNAL_USERS || !$ismyuser || !qa_opt('allow_private_messages') || !qa_opt('show_message_history'))
			unset($navigation['messages']);

		return $navigation;
	}

