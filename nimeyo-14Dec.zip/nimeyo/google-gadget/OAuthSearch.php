<?php

require_once("OAuth.php");
require '../qa-include/qa-base.php';
require_once '../qa-include/qa-app-search.php';
require_once '../qa-plugin/qa-ldap-login/ldap-login.php';
require_once '../qa-plugin/qa-access-control/qa-access-control.php';
require '../qa-include/qa-db-selects.php';
require_once '../qa-include/qa-db.php';

function getBase() {
	$url  = @( $_SERVER["HTTPS"] != 'on' ) ? 'http://'.$_SERVER["SERVER_NAME"] :  'https://'.$_SERVER["SERVER_NAME"];
	if (( $_SERVER["SERVER_PORT"] != 80 ) && ( $_SERVER["SERVER_PORT"] != 443)) {
		$url .= ":".$_SERVER["SERVER_PORT"];
	}
	return $url;
}

//This is a stub for a function that needs to be created in qPod.
//id - is the google plus id of the user
//searchtext = is the text to search for
//returns - should return an array of array for each result - up to 10 results.  The key "value" should have the search header, and the key "link" should have the link
function qPod_search_results($id, $searchtext, $body, &$query) {
	
	// Get the userid
	$userid = qa_db_read_one_value(qa_db_query_sub("SELECT userid FROM ^userlogins WHERE source = 'google' AND identifier = $", $id), true);
	if (isset($userid)) {
		require_once '../qa-include/qa-app-users.php';
		require_once '../qa-include/qa-db-users.php';
		// qa_set_logged_in_user($userid); // default source // could cause "Code not correct" with password reset (as emailcode would be cleared by this call)
		qa_set_logged_in_user(null);
		qa_set_session_user($userid, 'GmailGadget');
	}
	//error_log("ID $id = $userid searching for '$searchtext'");

	require_once QA_BASE_DIR.'submit/qpod-submit-utils.php';
	$tags = qpod_extract_tags('', $body, 'questions');
	$tags = implode(' ', $tags);
	$searchtext .= ' ' . $tags;
	$query = $searchtext;
	//error_log("body -> tags: $tags");
	//error_log("searchtext: $searchtext");

	$results_of_search = qa_get_search_results($searchtext, 0, 5, $userid, true, false);
	//error_log("Results = " . print_r($results_of_search,true));

	$base = getBase();

	$results = array();
	foreach ($results_of_search as &$hit) {
		$goodlink = str_replace('http:\/\/qpod', $base, $hit['url']);
		$goodlink = str_replace("http://qpod", $base, urldecode($hit['url']));
		$excerpt = $hit['best_match_post']->excerpt;
		//$unixtime_to_date = date('F jS Y h:i:s A', $hit['question']['created']);
		$unixtime_to_date = date('F jS Y', $hit['question']['created']);
		$result_hit = array("value"=>$hit['title'], "link"=>$goodlink, "excerpt"=>$excerpt, "user"=>$hit['question']['handle'], "date"=>$unixtime_to_date, "category"=>$hit['question']['categoryname'], "categorypath"=>$hit['question']['categorybackpath']);

		$results[] = $result_hit;
	}
	
	
	//Fake results
	//$result1 = array("value"=>"what percent of 897.77 is 84.95?", "link"=>"http://mathhomeworkanswers.org/10429/what-percent-of-897-77-is-84-95?show=111375#a111375");
	//$result2 = array("value"=>"Find the critical value for a left-tailed test with mathml equation = 0.025 and n = 50.", "link"=>"http://mathhomeworkanswers.org/94691/find-critical-value-left-tailed-test-with-mathml-equation-025?show=94691#q94691");
	///$result3 = array("value"=>"if caroline and ann hiked 3 1/4 miles before taking a break and 1 7/8 miles after how many miles did they hike?", "link"=>"http://mathhomeworkanswers.org/105/caroline-hiked-miles-before-taking-break-miles-after-miles");

	//$results = array($result1);
	//$results[] = $result2;
	//$results[] = $result3;
	
	return $results;
}

//Check for authentic siguature
 
//From: http://developer.studivz.net/wiki/index.php/Lesson_10:_Interact_with_your_own_Backend
class MyOAuthSignatureMethod_RSA_SHA1 extends OAuthSignatureMethod_RSA_SHA1 {
	protected function fetch_public_cert(&$request) {
$cert =  "-----BEGIN CERTIFICATE-----\nMIIDBDCCAm2gAwIBAgIJAK8dGINfkSTHMA0GCSqGSIb3DQEBBQUAMGAxCzAJBgNV\nBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzETMBEG\nA1UEChMKR29vZ2xlIEluYzEXMBUGA1UEAxMOd3d3Lmdvb2dsZS5jb20wHhcNMDgx\nMDA4MDEwODMyWhcNMDkxMDA4MDEwODMyWjBgMQswCQYDVQQGEwJVUzELMAkGA1UE\nCBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxEzARBgNVBAoTCkdvb2dsZSBJ\nbmMxFzAVBgNVBAMTDnd3dy5nb29nbGUuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GN\nADCBiQKBgQDQUV7ukIfIixbokHONGMW9+ed0E9X4m99I8upPQp3iAtqIvWs7XCbA\nbGqzQH1qX9Y00hrQ5RRQj8OI3tRiQs/KfzGWOdvLpIk5oXpdT58tg4FlYh5fbhIo\nVoVn4GvtSjKmJFsoM8NRtEJHL1aWd++dXzkQjEsNcBXwQvfDb0YnbQIDAQABo4HF\nMIHCMB0GA1UdDgQWBBSm/h1pNY91bNfW08ac9riYzs3cxzCBkgYDVR0jBIGKMIGH\ngBSm/h1pNY91bNfW08ac9riYzs3cx6FkpGIwYDELMAkGA1UEBhMCVVMxCzAJBgNV\nBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRMwEQYDVQQKEwpHb29nbGUg\nSW5jMRcwFQYDVQQDEw53d3cuZ29vZ2xlLmNvbYIJAK8dGINfkSTHMAwGA1UdEwQF\nMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAYpHTr3vQNsHHHUm4MkYcDB20a5KvcFoX\ngCcYtmdyd8rh/FKeZm2me7eQCXgBfJqQ4dvVLJ4LgIQiU3R5ZDe0WbW7rJ3M9ADQ\nFyQoRJP8OIMYW3BoMi0Z4E730KSLRh6kfLq4rK6vw7lkH9oynaHHWZSJLDAp17cP\nj+6znWkN9/g=\n-----END CERTIFICATE-----";
		return $cert;
	}
	protected function fetch_private_cert(&$request) {
		return;
	}
}

$request = OAuthRequest::from_request();
$server = new MyOAuthSignatureMethod_RSA_SHA1();
$return = $server->check_signature($request, null, null, $_GET['oauth_signature']);

if ($return) {
	$value = "yes";
	$id = $_GET['opensocial_owner_id'];
} else {
	$value = "invalid signature";
	$id = null;
	$return = !qa_opt('closed_site_enabled'); // may still allow search if not closed site
}

$values = array();

if ($return) {
	//error_log("OAuthSearch GET : " . print_r($_GET,true));
	//error_log("OAuthSearch POST : " . print_r($_POST,true));
	//error_log("SERVER : " . print_r($_SERVER,true));

	$values = qPod_search_results($_GET['opensocial_owner_id'], $_GET['searchstring'], $_POST['body'], $query);
}
	
$output = array
  (
  array("verified"=>$value),
  array("values"=>$values),
  array("query"=>$query),
  );
  
echo json_encode($output);

