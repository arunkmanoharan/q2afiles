<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-app-emails.php
	Description: Wrapper functions for sending email notifications to users


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

	if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
		header('Location: ../');
		exit;
	}

	require_once QA_INCLUDE_DIR.'app/options.php';


	function qa_suspend_notifications($suspend=true)
/*
	Suspend the sending of all email notifications via qa_send_notification(...) if $suspend is true, otherwise
	reinstate it. A counter is kept to allow multiple calls.
*/
	{
		global $qa_notifications_suspended;

		$qa_notifications_suspended+=($suspend ? 1 : -1);
	}


	function qa_send_notification($userid, $email, $handle, $subject, $body, $subs, $replyto=null, $params=null, $html = true)
/*
	Send email to person with $userid and/or $email and/or $handle (null/invalid values are ignored or retrieved from
	user database as appropriate). Email uses $subject and $body, after substituting each key in $subs with its
	corresponding value, plus applying some standard substitutions such as ^site_title, ^handle and ^email.
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

		global $qa_notifications_suspended;

		if ($qa_notifications_suspended>0)
			return false;

		require_once QA_INCLUDE_DIR.'db/selects.php';
		require_once QA_INCLUDE_DIR.'util/string.php';

		if (isset($userid)) {
			$needemail=!qa_email_validate(@$email); // take from user if invalid, e.g. @ used in practice
			$needhandle=empty($handle);

			if ($needemail || $needhandle) {
				if (QA_FINAL_EXTERNAL_USERS) {
					if ($needhandle) {
						$handles=qa_get_public_from_userids(array($userid));
						$handle=@$handles[$userid];
					}

					if ($needemail)
						$email=qa_get_user_email($userid);

				} else {
					$useraccount=qa_db_select_with_pending(
						array(
							'columns' => array('email', 'handle'),
							'source' => '^users WHERE userid = #',
							'arguments' => array($userid),
							'single' => true,
						)
					);

					if ($needhandle)
						$handle=@$useraccount['handle'];

					if ($needemail)
						$email=@$useraccount['email'];
				}
			}
		}

		if (isset($email) && qa_email_validate($email)) {
			$subs['^site_title']=qa_opt('site_title');
			$subs['^handle']=$handle;
			$subs['^email']=$email;
			$subs['^open']="\n";
			$subs['^close']="\n";
		
			if ($html) {
				$url_keys = array('^url', '^a_url');
				foreach ($url_keys as $key) {
					if (@$subs[$key] && substr($subs[$key], 0, 1) !== '<') {
						$subs[$key] = "<a href='{$subs[$key]}'>{$subs[$key]}</a>";
					}
				}
			}

			return qa_send_email(array(
				'replyto' => @$replyto,
				'fromemail' => qa_opt('from_email'),
				'fromname' => qa_opt('site_title'),
				'toemail' => $email,
				'toname' => $handle,
				'subject' => strtr($subject, $subs),
				'body' => qa_strtr((empty($handle) ? '' : qa_lang_sub('emails/to_handle_prefix', $handle)).$body, $subs),
				'html' => $html,
				'customheaders' => @$params['customheaders'],
			));

		} else
			return false;
	}


	function qa_send_email_bulk_via_bcc($subject, $body, $emails, $params=array())
	{
		if (empty($emails)) return false;

		// $params can override below settings
		$message = $params + array(
			'fromemail' => qa_opt('from_email'),
			'fromname' => qa_opt('site_title'),
			'subject' => $subject,
			'body' => $body,
			'html' => true,
		);

		$n = count($emails);
		$cnt = 75; // at most 75 recipients at a time as smtp server may impose a limit
		$status = true;
		for ($i = 0; $i < $n; $i += $cnt)
		{
			$message['bcclist'] = array_slice($emails, $i, $i+$cnt);
			$status &= qa_send_email($message);
		}
		return $status;
	}


	function is_html($text)
	{
		return preg_match('/<\/[a-z]+>|<br[\/\s]*>/i', $text);
		//return $text != strip_tags($text);
	}


	function qa_strtr($body, $subs, $html=true)
	{
		if ($html) {
			// escape special chars, e.g. "\n" to <br> for text that don't look like html
			if (!is_html($body))
			$body = qa_html($body, true);
			foreach ($subs as &$sub)
				if (!is_html($sub))
					// don't look like html. escape special chars.
					$sub = qa_html($sub, true);
		}

		return strtr($body, $subs);
	}


	function qa_email_confined($to, $bccs=null)
	{
		return false;

		if (!isset($bccs)) $bccs = array();
		$to = array_merge(array($to), $bccs);
		foreach ($to as $addr) {
			if (!preg_match('/@nimeyo\.com$/i', $addr))
				return true;
		}
		return false;
	}


	function qa_send_email_set_enable($state)
	{
		global $send_email_disabled;
		$send_email_disabled = !$state;
	}


	function qa_send_email($params)
/*
	Send the email based on the $params array - the following keys are required (some can be empty): fromemail,
	fromname, toemail, toname, subject, body, html
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

	//	@error_log(print_r($params, true));

		global $send_email_disabled;
		if ($send_email_disabled) {
			// use json_encode in case we ever need to resend this email so we can decode it back
			error_log('Send email was disabled for : '.json_encode($params));
			file_put_contents(QPOD_LOG_DIR.'suspended_notifications.log', json_encode($params), FILE_APPEND);
			return true;
		}
		
		$opt_email_confined = qa_opt_reload('email_confined');
		$opt_email_confined_type = qa_opt_reload('email_confined_type');
		if ($opt_email_confined && $opt_email_confined_type == 'f') {
			return file_put_contents(QPOD_LOG_DIR.'out_emails.log', print_r($params,true), FILE_APPEND);
		}

		if (!isset($params['bcclist']))
			$params['bcclist'] = array();

		$actual_recipients = '';
		if ($opt_email_confined || qa_email_confined(@$params['toemail'], @$params['bcclist'])) {
			$newline = $params['html'] ? '<br>' : "\n";
			if (isset($params['toemail']))
				$actual_recipients .= '!To: ' . $params['toemail'] . $newline;
			foreach ($params['bcclist'] as $email)
				$actual_recipients .= '!Bcc: ' . $email . $newline;
			$actual_recipients .= $newline;

			$params['bcclist'] = array();
			$params['toemail'] = qa_opt('feedback_email');
		}

		if (qa_opt_reload('email_bcc_qa_from_email') && qa_opt('from_email')) {
			$params['bcclist'] []= qa_opt('from_email');
		}

		$params['body'] = $actual_recipients . $params['body'];

		if (qa_opt('email_smtp_oauth2'))
			return OAuth2Smtp::send_email($params);
		else
			return qa_send_email_original($params);
	}


	function qa_send_email_original($params)
	{
		require_once QA_INCLUDE_DIR.'vendor/PHPMailer/PHPMailerAutoload.php';

		$mailer=new PHPMailer();
		$mailer->CharSet='utf-8';

		if (!empty($params['replyto']))
			$mailer->AddReplyTo($params['replyto']); // need to be done before setting from. see: http://stackoverflow.com/a/10432807/1533634

		$mailer->From=$params['fromemail'];
		$mailer->Sender=$params['fromemail'];
		$mailer->FromName=$params['fromname'];

		if (isset($params['customheaders']))
			foreach ($params['customheaders'] as $c)
				$mailer->AddCustomHeader($c);

			if (isset($params['toemail']))
			$mailer->AddAddress($params['toemail'], @$params['toname']);

			if (isset($params['bcclist']))
				foreach ($params['bcclist'] as $email)
					$mailer->AddBCC($email);

		$mailer->Subject=$params['subject'];
		$mailer->Body=$params['body'];

		if ($params['html'])
			$mailer->IsHTML(true);

		if (qa_opt('smtp_active')) {
			$mailer->IsSMTP();
			$mailer->Host=qa_opt('smtp_address');
			$mailer->Port=qa_opt('smtp_port');

			if (qa_opt('smtp_secure')){
				$mailer->SMTPSecure=qa_opt('smtp_secure');
			}
			else {
				$mailer->SMTPOptions=array(
					'ssl' => array(
						'verify_peer' => false,
						'verify_peer_name' => false,
						'allow_self_signed' => true
					)
				);
			}

			if (qa_opt('smtp_authenticate')) {
				$mailer->SMTPAuth=true;
				$mailer->Username=qa_opt('smtp_username');
				$mailer->Password=qa_opt('smtp_password');
			}
		}

		$send_status = $mailer->Send();
		if(!$send_status){
			@error_log('PHP Question2Answer email send error: '.$mailer->ErrorInfo);
		}
		return $send_status;
	}


	class OAuth2Smtp {

		static private $userid;
		static private $provider_config;
		static private $login_module;
		static private $transport;

		// return mapping of ^userlogins.source to array(provider, host, port, ssl).
		// provider must match name in Hybrid Auth.
		// source and provider are case-sensitive.
		static public function known_oauth2_smtp_servers()
		{
			return array(
				'google' => array('Google', 'smtp.gmail.com', 465, 'ssl'),
			);
		}

		static private function get_source_for($userid)
		{
			return qa_db_read_one_value(qa_db_query_sub(
				'SELECT source FROM ^userlogins WHERE userid=# AND source IN ($) AND LENGTH(refresh_token)>0 LIMIT 1',
				$userid, array_keys(self::known_oauth2_smtp_servers())
			), true);
		}

		static private function get_provider_config()
		{
			if (!isset(self::$provider_config)) {
				require_once QA_INCLUDE_DIR.'qa-db-users.php';
				$userids = qa_db_user_find_by_email(qa_opt('smtp_username'));
				if (count($userids) == 1) {
					self::$userid = reset($userids);
				} else {
					qa_fatal_error('There are more than one users with email = '.qa_opt('smtp_username'));
				}
				$source = self::get_source_for(self::$userid);
				$servers = self::known_oauth2_smtp_servers();
				self::$provider_config = @$servers[$source];
			}
			return self::$provider_config;
		}

		static private function get_login_module()
		{
			if (!isset(self::$login_module)) {
				$config = self::get_provider_config();
				if (!empty($config))
					self::$login_module = qa_load_module('login', $config[0]);
			}
			return self::$login_module;
		}

		static public function get_access_token()
		{
			$login_module = self::get_login_module();
			if (isset($login_module)) {
				return $login_module->get_access_token(self::$userid);
			}
			return null;
		}

		static public function refresh_access_token()
		{
			$login_module = self::get_login_module();
			if (isset($login_module)) {
				return $login_module->refresh_access_token(self::$userid);
			}
			return null;
		}

		static public function logout()
		{
			self::$transport = null; // cannot use unset()
		}

		// adapted from http://piecewiseinc.blogspot.com/2013/02/send-mail-with-gmail-smtp-and-xoauth.html
		static private function get_transport()
		{
			if (isset(self::$transport)) return self::$transport;

			$email = qa_opt('smtp_username');
			$accessToken = self::get_access_token();

			$smtpInitClientRequestEncoded = base64_encode("user=$email\1auth=Bearer $accessToken\1\1");
			list ($provider, $host, $port, $ssl) = self::get_provider_config();
			$config = array(
				'ssl' => $ssl,
				'port' => $port,
				'auth' => 'xoauth',
				'xoauth_request' => $smtpInitClientRequestEncoded,
			);

			return self::$transport = new Zend_Mail_Transport_Smtp($host, $config);
		}

		static public function send_email($params)
		{
			set_include_path(PHP_INCLUDE_DIR); // Zend may include other files assuming this include path
			require_once PHP_INCLUDE_DIR.'Zend/Mail/Transport/Smtp.php';
			require_once PHP_INCLUDE_DIR.'Zend/Mail.php';

			$transport = self::get_transport();
			$mail = new Zend_Mail();

			if (!empty($params['replyto']))
				$mail->setReplyTo($params['replyto']); // need to be done before setting from. see: http://stackoverflow.com/a/10432807/1533634

			if (isset($params['customheaders'])) {
				foreach ($params['customheaders'] as $c) {
					$h = explode(':', $c, 2);
					$mail->addHeader($h[0], $h[1]);
				}
			}

			if (isset($params['toemail']))
				$mail->addTo($params['toemail'], $params['toname']);

			if (isset($params['bcclist']))
				foreach ($params['bcclist'] as $email)
					$mail->addBcc($email);

			$mail->setFrom($params['fromemail'], $params['fromname']);
			$mail->setSubject($params['subject']);

			if ($params['html'])
				$mail->setBodyHtml($params['body']);
			else
				$mail->setBodyText($params['body']);

			try {
				$result = $mail->send($transport);
			} catch (Exception $e) {
				error_log('refreshing access_token as qa_send_email_oauth2 failed with : ' . $e->getMessage());
				// refresh access token and retry
				try {
					self::logout(); // unset old transport
					self::refresh_access_token();
					$transport = self::get_transport();
					$result = $mail->send($transport);
				} catch (Exception $e) {
					error_log('unable to refresh access_token : ' . $e->getMessage());
					return false;
				}
			}

			return $result;
		}

	} // class OAuth2Smtp


/*
	Omit PHP closing tag to help avoid accidental output
*/
