<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-page-search.php
	Description: Controller for search page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

	if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
		header('Location: ../');
		exit;
	}

	require_once QA_INCLUDE_DIR.'app/format.php';
	require_once QA_INCLUDE_DIR.'app/options.php';
	require_once QA_INCLUDE_DIR.'app/search.php';


//	Perform the search if appropriate

	if (strlen(qa_get('q'))) {
	
	//	Pull in input parameters
	
		$inquery=trim(qa_get('q'));
		$userid=qa_get_logged_in_userid();
		$start=qa_get_start();
		
		$display=qa_opt_if_loaded('page_size_search');
		$count=2*(isset($display) ? $display : QA_DB_RETRIEVE_QS_AS)+1;
			// get enough results to be able to give some idea of how many pages of search results there are

	//  Setting Solr's boost values

		if (qa_opt('solr_boosts_tunable')) {
			foreach ($_POST as $key => $value) {
				if (strpos($key, 'boost_') === 0)
					qa_opt($key, floatval($value));
			}
		}

	//  Web API request - Pre

		$absoluteurls = false;
		$results = null;
		$error = null;

		if (qa_get('out') == 'json') {
			$absoluteurls = true;
		}

		if ($provider = qa_get('provider')) {
			$modules = qa_load_modules_with('module', 'get_search_results');
			$provider_module = @$modules[$provider];
			if (isset($provider_module))
				$results = $provider_module->get_search_results(qa_get_logged_in_userid(), $inquery, $error);
		}

	//	Get sort options (prefer GET to POST so that revisiting via browser's back button doesn't need resubmit)

		$search_params = qa_get_search_params(true);
		$minanswers = qa_get('minanswers');
		$sort = qa_get('sort');
		$sort_options = array(
			'S' => qa_lang_html('main/relevance'),
			'A' => qa_lang_html('main/num_answers'),
			'V' => qa_lang_html('main/num_votes'),
			'D' => qa_lang_html('main/time'),
		);
		// $sort and $sort_options will also be used later

	//	Perform the search using appropriate module

		if (isset($results)) {
			// specialized provider
			if (!qa_get('solr_only')) { // workaround where $start is not passed to data source yet (but it is used by solr_only)
				$results = array_slice($results, $start); // TODO: or should we pass $start to provider
			}
		} else {
			// normal Q2A search
			$results=qa_get_search_results($inquery, $start, $count, $userid, $absoluteurls, false, $search_params);
		}

	//	Count and truncate results
		
		$pagesize=qa_opt('page_size_search');
		$gotcount=count($results);
		$results=array_slice($results, 0, $pagesize);
		
	//	Sort the results *within this page only* (may be cleaner to do it on client-side javascript but doing it server-side allows sort option to be sticky through other pages)

		function sort_results_by(&$results, $key)
		{
			$indexes = array_keys($results); // so that we can use original order for tie breaking
			usort($indexes, function($a, $b) use ($key, $results) {
				$diff = $results[$b]['question'][$key] - $results[$a]['question'][$key];
				if ($diff == 0) $diff = $a - $b; // retain original order for tie breaking
				// be careful that if $diff is float it will be rounded down to int
				return $diff;
			});
			$results = array_map(function($i) use ($results) { return $results[$i]; }, $indexes);
		}

		if (isset($sort)) {
			switch ($sort) {
				case 'A':
					sort_results_by($results, 'acount');
					break;
				case 'V':
					sort_results_by($results, 'netvotes');
					break;
				case 'D':
					sort_results_by($results, 'created');
					break;
				default:
			}
		}

	//	Report the search event

		$event_params = isset($search_params['tab']) ? [ 'tab' => $search_params['tab'] ] : [];
		$event_params += array(
			'query' => $inquery,
			'start' => $start,
		);
		qa_report_event('search', $userid, qa_get_logged_in_handle(), qa_cookie_get(), $event_params);

	//  Web API request - Post

		if (process_web_api_request($results, $output, $error))
			return $output;

	//	Retrieve extra information on users	
		
		$fullquestions=array();
		
		foreach ($results as $result)
			if (isset($result['question']))
				$fullquestions[]=$result['question'];
				
		$usershtml=qa_userids_handles_html($fullquestions);
	}


//	Prepare content for theme

	$qa_content=qa_content_prepare(true);

	if (isset($error))
		$qa_content['custom_error'] = '<h4>' . $error . '</h4>'; // assume $error is safe from injection (else = must call qa_html() but will lose html links)

	if (strlen(qa_get('q'))) {
		//$qa_content['search']['value']=qa_html($inquery); // now done by qa_content_prepare

		// TODO: the following two UI tweaks should be moved to qa-theme-base.php 

		//  Control for sorting search results
		if (true) { // qa_opt('sort_search_results')?
			$self_url = qa_self_html(false);

			// use qa-page-links css style in addition to classic checkbox for better(?) UI
			$nonzero_current_class = @$minanswers ? 'qa-page-selected' : 'qa-page-link';
			$nonzero_checked = @$minanswers ? 'checked' : '';
			$search_params['minanswers'] = !@$search_params['minanswers']; // toggle (may degenerate manually-supplied int to bool)
			$nonzero_toggle_url = qa_path_html(qa_request(), $search_params);
			$search_params['minanswers'] = !@$search_params['minanswers']; // restored original value

			$tmp_params = $search_params;
			unset($tmp_params['sort']); // drop it from $params as we will be supplying it again
			$params = qa_path_form_html(qa_request(), $tmp_params); // URL params in GET ACTION will be lost. so, explicitly include them as hidden params.
			$options = '';
			foreach ($sort_options as $key => $text) {
				$options .= "<OPTION VALUE='$key'" . ($key == $sort ? " selected" : "") . ">$text</OPTION>";
			}

			// set up onclick to toggle value of 'minanswers', submit form and prevent default <a> action
			$onclick = "$('input[name=minanswers]').val(1-$('input[name=minanswers]').val()); ajax_submit_search_page($(this).closest('form')); return false;";
			$exclude_unanswered = qa_lang_html('main/exclude_unanswered');
			$qa_content['custom_sorter'] = <<<____________HTML
				<FORM METHOD="GET" ACTION="$self_url">
				$params
				<TABLE WIDTH="100%"><TR>
				<TD>
				<UL CLASS="qa-page-links-list"><LI CLASS="qa-page-links-item">
					<A HREF="$nonzero_toggle_url" CLASS="$nonzero_current_class" ONCLICK="$onclick">
						<INPUT TYPE="CHECKBOX" $nonzero_checked/>
						$exclude_unanswered
					</A>
				</LI></UL>
				</TD>
				<TD STYLE="text-align:right">
				<SPAN>Sort results <b>within</b> this page by: </SPAN>
				<SELECT NAME="sort" ONCHANGE="add_search_param_hidden('sort', this.value); ajax_submit_search_page(this.form);">$options</SELECT>
				</TD>
				</TR></TABLE>
				</FORM>
				<BR>
____________HTML;
		}

		// required by below knobs and fancytree
		$qa_content['script_rel'] []= 'qa-content/jquery-ui-1.10.3.min.js';
		$qa_content['css_src'] []= qa_path('qa-content/jquery-ui-1.10.3.min.css');

		//  Knobs for tuning Solr search
		if (qa_opt('solr_boosts_tunable')) {
			$boosts = array(
				'title' => 'title of main question',
				'content' => 'content of post',
				'tags' => 'tags',
				'user' => 'name or email of poster',
				'netvotes' => 'net votes of post',
				'bestanswers' => 'best answers', // TODO: 'best responses'
				'voteups' => 'my positive votes',
				'fav_qs' => 'favorite questions',
				'fav_tags' => 'favorite tags',
				'fav_users' => 'favorite users',
				'fav_categories' => 'favorite categories',
			);
			$html = '<TR ALIGN="CENTER">';
			$font_size = 'STYLE="font-size:10px"';
			foreach (array_keys($boosts) as $boost)
				$html .= "<TD $font_size>$boost</TD>";
			$html .= '</TR><TR>';
			foreach ($boosts as $boost => $description) {
				$boost = 'boost_' . $boost;
				$value = qa_opt($boost);
				//$html .= '<TD><INPUT ONCHANGE="this.form.submit();" TYPE="NUMBER" STEP=0.5 MIN="-99.0" MAX="99.0" NAME="' . $boost . '" VALUE="' . qa_opt($boost) . '"></INPUT></TD>';
				$html .= <<<________________HTML
					<TD $font_size TITLE="$description"><INPUT CLASS="spinner" ONCHANGE="this.form.submit();" SIZE="2" NAME="$boost" VALUE="$value"></INPUT></TD>
________________HTML;
			}
			$html .= '</TR>';

			$qa_content['script_onloads'] []= <<<____________JS
				$('.spinner').spinner({step:0.5});
				$('.ui-spinner-button').click(function() { $(this).siblings('input').change(); });
____________JS;

			$self_url = qa_self_html();
			$qa_content['custom_knobs'] = <<<____________HTML
				<FORM METHOD="POST" ACTION="$self_url">
				<TABLE>$html</TABLE>
				</FORM>
				<BR>
____________HTML;
		}

		// checking non existing words should be applicable only to native qpod content
		if (!isset($provider_module)) {
			$searchmodules = qa_load_modules_with('search', 'qa_html_check_non_existing_words');
			foreach ($searchmodules as $searchmodule) {
				$inquery_html = $searchmodule->qa_html_check_non_existing_words($inquery);
				if (!empty($inquery_html)) break;
			}
		}

		if (empty($inquery_html))
			$inquery_html = qa_html($inquery);

		if (count($results))
			$qa_content['title']=qa_lang_html_sub('main/results_for_x', $inquery_html);
		else
			$qa_content['title']=qa_lang_html_sub('main/no_results_for_x', $inquery_html);
			
		$qa_content['q_list']['form']=array(
			'tags' => 'method="post" action="'.qa_self_html().'"',

			'hidden' => array(
				'code' => qa_get_form_security_code('vote'),
			),
		);
		
		$qa_content['q_list']['qs']=array();
		
		$qdefaults=qa_post_html_defaults('Q');
		$qdefaults['categorypathprefix'] = 'questions/'; // for pagination footer. without prefix = recent activities, which doesn't provide pagination
		
		foreach ($results as $result)
			if (!isset($result['question'])) { // if we have any non-question results, display with less statistics
				$qdefaults['voteview']=false;
				$qdefaults['answersview']=false;
				$qdefaults['viewsview']=false;
				break;
			}
		
		foreach ($results as $result) {
			if (isset($result['question']))
				$fields=qa_post_html_fields($result['question'], $userid, qa_cookie_get(),
					$usershtml, null, qa_post_html_options($result['question'], $qdefaults));
			
			elseif (isset($result['url']))
				$fields=array(
					'what' => qa_html($result['url']),
					'meta_order' => qa_lang_html('main/meta_order'),
				);

			else
				continue; // nothing to show here
			
			if (isset($qdefaults['blockwordspreg']))
				$result['title']=qa_block_words_replace($result['title'], $qdefaults['blockwordspreg']);
				
			//$fields['title']=qa_html($result['title']);
			$fields['url']=qa_html($result['url']);
			$fields['url_external']=qa_html(@$result['url_external']);
			if (isset($result['best_match_post']))
				$fields['content'] = $result['best_match_post']->{'excerpt'};
			
			$qa_content['q_list']['qs'][]=$fields;
		}

		$qa_content['page_links']=qa_html_page_links(qa_request(), $start, $pagesize, $start+$gotcount,
			qa_opt('pages_prev_next'), $search_params, $gotcount>=$count);
		
		if (qa_opt('feed_for_search'))
			$qa_content['feed']=array(
				'url' => qa_path_html(qa_feed_request('search/'.$inquery)),
				'label' => qa_lang_html_sub('main/results_for_x', $inquery_html),
			);

		if (empty($qa_content['page_links']))
			$qa_content['suggest_next']=qa_html_suggest_qs_tags(qa_using_tags());

	} else
		$qa_content['error']=qa_lang_html('main/search_explanation');
	
	if (!isset($error)) {
		qa_allow_page_cache("max-age=300, private");
	}
	echo "<pre>";
		print_r($qa_content);
	echo "</pre>";
	return $qa_content;


/*
	Omit PHP closing tag to help avoid accidental output
*/