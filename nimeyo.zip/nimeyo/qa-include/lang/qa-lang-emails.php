<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-lang-emails.php
	Description: Language phrases for email notifications


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

	return array(
		'a_commented_body' => "Your answer on ^site_title has a new comment by ^c_handle:\n\n^open^c_content^close\n\nYour answer was:\n\n^open^c_context^close\n\nYou may respond by adding your own comment:\n\n^url\n\nThank you,\n\n^site_title",
		'a_commented_subject' => 'Your ^site_title answer has a new comment',

		'a_followed_body' => "Your answer on ^site_title has a new related question by ^q_handle:\n\n^open^q_title^close\n\nYour answer was:\n\n^open^a_content^close\n\nClick below to answer the new question:\n\n^url\n\nThank you,\n\n^site_title",
		'a_followed_subject' => 'Your ^site_title answer has a related question',

		'a_selected_body' => "Congratulations! Your answer on ^site_title has been selected as the best by ^s_handle:\n\n^open^a_content^close\n\nThe question was:\n\n^open^q_title^close\n\nClick below to see your answer:\n\n^url\n\nThank you,\n\n^site_title",
		'a_selected_subject' => 'Your ^site_title answer has been selected!',

		'c_commented_body' => "A new comment by ^c_handle has been added after your comment on ^site_title:\n\n^open^c_content^close\n\nThe discussion is following:\n\n^open^c_context^close\n\nYou may respond by adding another comment:\n\n^url\n\nThank you,\n\n^site_title",
		'c_commented_subject' => 'Your ^site_title comment has been added to',

		'confirm_body' => "Please click below to confirm your email address for ^site_title.\n\n^url\n\nThank you,\n^site_title",
		'confirm_subject' => '^site_title - Email Address Confirmation',

		'feedback_body' => "Comments:\n^message\n\nName:\n^name\n\nEmail:\n^email\n\nPrevious page:\n^previous\n\nUser:\n^url\n\nIP address:\n^ip\n\nBrowser:\n^browser",
		'feedback_subject' => '^ feedback',

		'flagged_body' => "A post by ^p_handle has received ^flags:\n\n^open^p_context^close\n\nClick below to see the post:\n\n^url\n\n\nClick below to review all flagged posts:\n\n^a_url\n\n\nThank you,\n\n^site_title",
		'flagged_subject' => '^site_title has a flagged post',

		// TODO: may want to say what 'post' is ('answer' or 'comment', but not 'question' which would be redundant)

		'moderate_body' => "A post by ^p_handle ^under_category ^c_category requires your approval:\n\n^open^p_context^close\n\nClick below to approve or reject the post:\n\n^url\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nThank you,\n\n^site_title",
		// above is deprecated and should be removed
		'moderate_body_q' => "You have received a ^t_type ^under_category ^c_category through qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was created by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'moderate_body_a' => "You have received an ^t_type ^under_category ^c_category through qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was created by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'moderate_body_c' => "You have received a ^t_type ^under_category ^c_category through qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was created by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'moderate_subject' => 'ACTION REQUIRED: ^site_title Moderation request for a new post.',

		'moderate_result_body' => "Your post in the following question was ^moderate_result by moderator:\n^open^p_context^close\n\n^commentClick below to view the post:\n\n^url\n\n\nThank you,\n\n^site_title",
		// above is deprecated and should be removed
		'moderate_result_body_q' => "Your following question was reviewed and ^moderate_result by moderator:\n^open^p_context^close\n\n^commentClick below to view the post:\n\n^url\n^moderate_result_approved_note\n\nThank you,\n\n^site_title",
		'moderate_result_body_a' => "Your answer in the following question was reviewed and ^moderate_result by moderator:\n^open^p_context^close\n\n^commentClick below to view the post:\n\n^url\n\n\nThank you,\n\n^site_title",
		'moderate_result_body_c' => "Your comment in the following question was reviewed and ^moderate_result by moderator:\n^open^p_context^close\n\n^commentClick below to view the post:\n\n^url\n\n\nThank you,\n\n^site_title",
		'moderate_result_comment_note' => "With following comment:",
		'moderate_result_subject' => '^site_title - Your post was ^moderate_result',
		'moderate_result_approved' => 'accepted',
		'moderate_result_rejected' => 'rejected',
		'moderate_result_approved_note' => "\n\nYou may be further notified when your question is answered.",

		'moderate_edited_body' => "Your post in the following question was edited by moderator (^u_handle):\n^open^p_context^close\n\nClick below to view the post:\n\n^url\n\n\nThank you,\n\n^site_title",
		'moderate_edited_subject' => '^site_title - Your post was edited by moderator',

		'new_password_body' => "Your new password for ^site_title is below.\n\nPassword: ^password\n\nIt is recommended to change this password immediately after logging in.\n\nThank you,\n^site_title\n^url",
		'new_password_subject' => '^site_title - Your New Password',

		/*                'notif_body' => "-------< When Replying, do not write anything below this line >---------\n\n^q_handle, You were mentioned on ^site_title.\n\nTitle and the body of the message below:\n\n^open^q_title^close\n\n^open^q_content^close\n\nIt is a good practice to check the discussion link below and respond with appropriate response. \n\nClick below link to view and respond to your reference \n\n^url\n\nThank you,\n^site_title",
                'notif_subject' => '^site_title - You were mentioned',
		*/

		// for qa-plugins/qa-notif (mention)
		'notif_body' => "^open^q_content^close\n\n------------------\nClick below link to view/respond \n^url\n",
		'notif_subject' => '[^site_title Alert] ^open^q_title^close',

		// -- begin messages for qa-plugins/qa-email-notif

		'notif_category_new_post_body' =>  "Link: ^url\nFrom: ^sender_handle ^sender_email\n\n^content",

		// TODO: why not reuse 'q_posted_subject' / 'q_posted_body'?
		'notif_user_q_post_subject' => "New ^site_title question: ^q_title",
		'notif_user_q_post_body' => "A question on ^site_title has been asked by ^q_handle:<br><br>The question is:<br><br>^open^q_title^close<br><br>^open^q_content^close<br><br>If you would like to view this question:<br><br>^url<br><br>Thank you,<br><br>^site_title",
		'notif_user_a_post_subject' => 'New ^site_title answer to: ^q_title',
		'notif_user_a_post_body' => "A question on ^site_title has been answered by ^a_handle:<br><br>^open^a_content^close<br><br>The question was:<br><br>^open^q_title^close<br><br>If you would like to view this question:<br><br>^url<br><br>Thank you,<br><br>^site_title",
		'notif_user_c_post_subject' => 'New ^site_title comment to: ^q_title',
		'notif_user_c_post_body' => "A question on ^site_title has been commented by ^c_handle:<br><br>^open^c_content^close<br><br>The question was:^open^q_title^close<br><br>If you would like to view this question:<br><br>^url<br><br>Thank you,<br><br>^site_title",

		// -- end messages for qa-plugins/qa-email-notif

		'private_message_body' => "You have been sent a private message by ^f_handle on ^site_title:\n\n^open^message^close\n\n^moreThank you,\n\n^site_title\n\n\nTo block private messages, visit your account page:\n^a_url",
		'private_message_info' => "More information about ^f_handle:\n\n^url\n\n",
		'private_message_reply' => "Click below to reply to ^f_handle by private message:\n\n^url\n\n",
		'private_message_subject' => 'Message from ^f_handle on ^site_title',

		'q_answered_body' => "Your question on ^site_title has been answered by ^a_handle:\n\n^open^a_content^close\n\nYour question was:\n\n^open^q_title^close\n\nIf you like this answer, you may select it as the best:\n\n^url\n\nThank you,\n\n^site_title",
		'q_answered_subject' => 'Your ^site_title question was answered',

		'q_commented_body' => "Your question on ^site_title has a new comment by ^c_handle:\n\n^open^c_content^close\n\nYour question was:\n\n^open^c_context^close\n\nYou may respond by adding your own comment:\n\n^url\n\nThank you,\n\n^site_title",
		'q_commented_subject' => 'Your ^site_title question has a new comment',

		'q_posted_body' => "A new question has been asked by ^q_handle:\n\n^open^q_title\n\n^q_content^close\n\nClick below to see the question:\n\n^url\n\nThank you,\n\n^site_title",
		'q_posted_subject' => '^site_title has a new question',
		
		'remoderate_body' => "An edited post by ^p_handle ^under_category ^c_category requires your reapproval:\n\n^open^p_context^close\n\nClick below to approve or hide the edited post:\n\n^url\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nThank you,\n\n^site_title",
		// above is deprecated and should be removed
		'remoderate_body_q' => "A ^t_type ^under_category ^c_category was edited on qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was edited by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'remoderate_body_a' => "An ^t_type in the following question ^under_category ^c_category was edited on qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was edited by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'remoderate_body_c' => "A ^t_type in the following question ^under_category ^c_category was edited on qPod:\n\n^open^p_context^close\n\n\nClick below to view the post:\n\n^url\n\nThis post was edited by ^p_handle.\n\n\nClick below to review all queued posts:\n\n^a_url\n\n\nPlease respond at your earliest convenience.\n\nThank you,\n\n^site_title",
		'remoderate_subject' => 'ACTION REQUIRED: ^site_title Moderation request for an edited post.',

		'reset_body' => "Please click below to reset your password for ^site_title.\n\n^url\n\nAlternatively, enter the code below into the field provided.\n\nCode: ^code\n\nIf you did not ask to reset your password, please ignore this message.\n\nThank you,\n^site_title",
		'reset_subject' => '^site_title - Reset Forgotten Password',

		'to_handle_prefix' => "^,\n\n",
		
		'u_registered_body' => "A new user has registered as ^u_handle.\n\nClick below to view the user profile:\n\n^url\n\nThank you,\n\n^site_title",
		'u_registered_subject' => '^site_title has a new registered user',
		'u_to_approve_body' => "A new user has registered as ^u_handle.\n\nClick below to approve the user:\n\n^url\n\nClick below to review all users waiting for approval:\n\n^a_url\n\nThank you,\n\n^site_title",
		
		'u_approved_body' => "You can see your new user profile here:\n\n^url\n\nThank you,\n\n^site_title",
		'u_approved_subject' => 'Your ^site_title user has been approved',

		'under_category' => 'under category',
		'wall_post_subject' => 'Post on your ^site_title wall',
		'wall_post_body' => "^f_handle has posted on your user wall at ^site_title:\n\n^open^post^close\n\nYou may respond to the post here:\n\n^url\n\nThank you,\n\n^site_title",

		'welcome_body' => "Thank you for registering for ^site_title.\n\n^custom^confirmYour login details are as follows:\n\nUsername: ^handle\nEmail: ^email\n\nPlease keep this information safe for future reference.\n\nThank you,\n\n^site_title\n^url",
		'welcome_confirm' => "Please click below to confirm your email address.\n\n^url\n\n",
		'welcome_subject' => 'Welcome to ^site_title!',
	);
	

/*
	Omit PHP closing tag to help avoid accidental output
*/
