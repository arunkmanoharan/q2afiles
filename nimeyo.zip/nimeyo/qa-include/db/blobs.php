<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-db-blobs.php
	Description: Database-level access to blobs table for large chunks of data (e.g. images)


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
	
	Modified by: Chaiyasit Manovit (chaiyasit@nimeyo.com)
				 5/11/13 ICT
	Changes:
	 - Storing blobs in files rather than in the database.
	 - Call 'index_blob' if available.
	Notes:
	 Intention is to make this modification an override.
	 But overwrite the code here for now for simpler debugging.
	 qa_default_option() may need to be overridden to add:
	 'blobstore_path' = ...
	 'blobstore_depth'?
	TODO:
	 Add Admin control to set 'blobstore_path'/'blobstore_depth'.
	 Must also give hint on SELinux context setup @ blobstore_path.
*/

	if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
		header('Location: ../');
		exit;
	}


	require_once QA_INCLUDE_DIR.'qa-db.php';
	require_once QA_INCLUDE_DIR.'qa-db-selects.php';


	// Default setting supports 10^(4*3) = 1 trillion files.
	define('QA_BLOBSTORE_EXPONENT', 4); // maximum 10^4 files per directory. not configurable.
	define('QA_BLOBSTORE_DEPTH', qa_opt('blobstore_depth') ? qa_opt('blobstore_depth') : 3); // min = 1 = flat
	define('QA_BLOBSTORE_PATH', qa_opt('blobstore_path') ? qa_opt('blobstore_path') : QA_BASE_DIR . '../data/blobstore');


	function qa_db_blob_filename_fullpath($blobid, $depth=QA_BLOBSTORE_DEPTH)
	{
		$len = $depth*QA_BLOBSTORE_EXPONENT;
		$padded_id = substr(str_repeat('0', $len) . $blobid, -$len);
		return QA_BLOBSTORE_PATH . DIRECTORY_SEPARATOR . join(DIRECTORY_SEPARATOR, str_split($padded_id, QA_BLOBSTORE_EXPONENT));
		//return join('/', array_splice(str_split($padded_id, QA_BLOBSTORE_EXPONENT), 0, -1)); // only the path
	}

	function qa_db_blob_create($content, $format, $sourcefilename=null, $userid=null, $cookieid=null, $ip=null, $postid=null)
/*
	Create a new blob in the database with $content and $format, other fields as provided 
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

		$dir = QA_BLOBSTORE_PATH;
		umask(0077); // strictest possible permission (no group/other access permission)
		if (!is_dir($dir)) {
			if (!mkdir($dir)) // try to auto-create
				// may fail e.g. SELinux context at parent dir is not httpd_sys_rw_content_t
				return null;
		}

		$depth = QA_BLOBSTORE_DEPTH;

		for ($attempt=0; $attempt<10; $attempt++) {
			$blobid = substr(qa_db_random_bigint(), -QA_BLOBSTORE_EXPONENT*$depth);

			if (qa_db_blob_exists($blobid)) {
				/* would be nice to auto increment depth but it would be more complex than this.
				 * eg. two concurrent requests, one collided and incrementing depth while the other not collided and writing the file.
				if ($attempt > 0) {
					// collide twice already. let's expand the blobstore.
					$lock_dir = $path . '/files.lock';
					if (mkdir($lock_dir, 0700)) {
						// successfully locked.
						// move all the files one level down and increment the 'blobstore_depth'.
						rename($path . '/files', $lock_dir . '/000'); // '000' must sync with QA_BLOBSTORE_EXPONENT
						qa_opt('blobstore_depth', $depth+1); // must do this before releasing the lock.
						rename($lock_dir, $path . '/files'); // release the lock.
					} else {
						// already locked by another thread. wait until the lock is released.
						while (is_dir($lock_dir)) sleep(3);
					}
					// next attempt should re-read 'blobstore_depth'.
				}
				*/
				continue;
			}

			$blob_filename = qa_db_blob_filename_fullpath($blobid, $depth);
			if (file_exists($blob_filename))
				continue; // keep existing file as it may be used by prev db snapshots (very low prob. though)

			/* TODO: should perhaps add columns:
			 *	hash : for dedup (solr has it auto-generated though)
			 *	permission : for fine-grained sharing (maybe permission is associated to post instead)
			 */
			$db_result = qa_db_query_sub_onerror(
				null, // no error report
				'INSERT INTO ^blobs (blobid, format, content, filename, userid, cookieid, createip, created, postid) VALUES (#, $, $, $, $, #, INET_ATON($), NOW(), #)',
				$blobid, $format, /*$content*/ '', $sourcefilename, $userid, $cookieid, $ip, $postid
			);

			if ($db_result === false)
				continue; // may occur when two concurrent INSERTs attempt same previously non-existing blobid but only one can succeed.

			// NOTE: must store file only after INSERT succeeded. otherwise, may race.
			mkdir(dirname($blob_filename), 0700, true); // recursive mkdir
			$result = file_put_contents($blob_filename, $content);
			if ($result === false) {
				// trouble writing file. undo the blob addition.
				qa_db_blob_delete($blobid);
				continue; // retry
			}

			// determine postid for inline blob uploaded by WYSIWYG editor for existing post ('edit' event).
			// for fresh post ('post' event), postid will only be allocated when post is submited.
			if (!isset($postid)) {
				// TODO1?: we can move this block up so we can immediately bind this blob to the postid when
				// inserted to db (for case we can properly detect $postid = 'edit' case).
				// but we then need to add this blob to 'existing_attachments[]' and have it checked so that it
				// won't get unintentionally removed by process_event().
				// TODO2?: disabled for now because when it detects postid for inline blob for 'edit' case
				// it will index the blob here and again in process_event() when we scan post's content for
				// inline blob and that will create duplicate solr documents for the same blob.
				/*
				if (qa_get('CKEditor')) {
					// postid is embedded in 'CKEditor' variable, e.g., 'a123_content' where 123 is postid
					if (preg_match('/\d+/', qa_get('CKEditor'), $matches))
						$postid = reset($matches);
				}
				*/
			}

			// Index this blob
			if (isset($postid)) {
				$searches = qa_load_modules_with('search', 'index_blob');
				if (!empty($searches)) {
					// index blob
					foreach ($searches as $search)
						$search->index_blob($blobid, $postid, $content, $format, $sourcefilename); // may pass more arguments in the future
				}
			}

			return $blobid;
		}
		
		return null;
	}
	
	
	function qa_db_blob_read($blobid)
/*
	Get the information about blob $blobid from the database
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

		if (!isset($blobid)) return null;

		$result = qa_db_read_one_assoc(qa_db_query_sub(
			'SELECT content, format, filename FROM ^blobs WHERE blobid=#',
			$blobid
		), true);

		$content = file_get_contents(qa_db_blob_filename_fullpath($blobid));
		if ($content === false) return null; // ===false means failure
		$result['content'] = $content;
		return $result;
	}
	
	
	function qa_db_blob_set_content($blobid, $content)
/*
	Change the content of blob $blobid in the database to $content (can also be null)
*/
	{
		qa_db_query_sub(
			'UPDATE ^blobs SET content=$ WHERE blobid=#',
			$content, $blobid
		);
	}
	
	
	function qa_db_blob_delete($blobid)
/*
	Delete blob $blobid in the database
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }

		// Unindex this blob
		$searches = qa_load_modules_with('search', 'unindex_blob');
		foreach ($searches as $search)
			$search->unindex_blob($blobid);

		qa_db_query_sub(
			'DELETE FROM ^blobs WHERE blobid=#',
			$blobid
		);

		// better for consistency to delete file as last step so that DB would never refer to non-existing files.
		// we already prevent races by disallowing new blob to use a blobid if corresponding file (still) exists.
		unlink(qa_db_blob_filename_fullpath($blobid));
	}

	
	function qa_db_blob_exists($blobid)
/*
	Check if blob $blobid exists in the database. Could check with blobstore instead.
*/
	{
		if (qa_to_override(__FUNCTION__)) { $args=func_get_args(); return qa_call_override(__FUNCTION__, $args); }
		
		return qa_db_read_one_value(qa_db_query_sub(
			'SELECT COUNT(*) FROM ^blobs WHERE blobid=#',
			$blobid
		)) > 0;
	}


	function qa_db_blob_bind($blobids, $postid)
/*
	For any of $blobids that are not binded to $postid, bind them and return those newly binded blobids.
*/
	{
		if (empty($blobids)) return $blobids;

		// ideally, want to have this UPDATE return affected rows directly.
		// but that feature is not supported in mysql.
		/*
		qa_db_query_sub(
			'UPDATE ^blobs SET postid=# WHERE postid IS NULL AND blobid IN (#)',
			$postid, $blobids
		);
		*/

		// TODO?: following two sql commands should be done in a transaction for ACID.
		// but for now, assume no one else is modifying this post at the same time.
		$to_be_binded = qa_db_read_all_values(qa_db_query_sub(
			'SELECT blobid FROM ^blobs WHERE postid IS NULL AND blobid IN (#)',
			$blobids
		));
		if (!empty($to_be_binded)) {
			qa_db_query_sub(
				'UPDATE ^blobs SET postid=# WHERE postid IS NULL AND blobid IN (#)',
				$postid, $to_be_binded
			);

			// index these unbinded blobs as that was not done at upload time (on WYSIWYG editor)
			// because postid was not yet allocated while composing a fresh post.
			$searches = qa_load_modules_with('search', 'index_blob');
			if (!empty($searches)) {
				// index blobs
				foreach ($to_be_binded as $blobid) {
					foreach ($searches as $search)
						$search->index_blob($blobid, $postid); // without content being passed, index_blob will load it from db.
				}
			}
		}

		return $to_be_binded;
	}


	function qa_db_blobs_count($questionids)
/*
	Return a map from questionid => total number of blobs under that question (including answer/comment)
*/
	{
		if (empty($questionids)) return array();

		if (1) {
			// better performance
			$questionids_sql = qa_db_questionids_to_postids_sql($questionids);
			$query = <<<____________SQL
				SELECT questionid, SUM(cnt) AS cnt
				FROM (
					SELECT q.*, (SELECT COUNT(blobid) FROM ^blobs b WHERE b.postid=q.postid) AS cnt
					FROM ($questionids_sql) q
				) qq
				GROUP BY questionid
____________SQL;
			return qa_db_read_all_assoc(qa_db_query_sub($query), 'questionid', 'cnt');
		} else {
			// SQL explanation
			// Subquery "q" is to compute postid => questionid relation.
			// Assume at most 2 levels ('C'omment -> 'A'nswer -> 'Q'uestion).
			// Subquery "c" is to compute postid => count(blobs) relation.
			// We then JOIN the two on postid and aggregate the result by
			// computing SUM of blob counts for each (GROUP BY) questionid.
			// LEFT JOIN will create NULL entry for questionid with no blobs.
			// RIGHT JOIN / JOIN will leave out NULL entries.
			$query = <<<____________SQL
				SELECT q.questionid, SUM(c.cnt) AS cnt
				FROM
				( SELECT
					postid,
					IF(	LEFT(type,1)='Q',
						postid,
						(SELECT IF(LEFT(type,1)='Q', postid, parentid) FROM ^posts pp WHERE pp.postid=p.parentid)
					) AS questionid
				  FROM ^posts p
				) q
				LEFT JOIN
				( SELECT postid, COUNT(blobid) AS cnt
				  FROM ^blobs
				  GROUP BY postid
				) c
				ON q.postid=c.postid
				WHERE q.questionid IN (#)
				GROUP BY q.questionid;
____________SQL;
			return qa_db_read_all_assoc(qa_db_query_sub($query, $questionids), 'questionid', 'cnt');
		}
	}


	function qa_db_blobs_count_annotate(&$array, $func_get_question_ref=null)
/*
	For each value of the $array, apply $func_get_question to get the *reference* of
	the question array it represents and annotate it with ['blobs_count'].
	IMPORTANT: Take notes of the usage of "&" to pass by reference.
*/
	{
		if (!isset($func_get_question_ref))
			$func_get_question_ref = function &(&$x) { return $x; }; // default identity function (pass by reference and return reference)

		$questionids = array();
		$questions = array();
		foreach ($array as &$value) {
			$q = &$func_get_question_ref($value);
			if (isset($q)) {
				$questionids []= $q['postid'];
				$questions []= &$q;
			}
		}

		$blobs_count = qa_db_blobs_count($questionids);

		foreach ($questions as &$q) {
			$q['blobs_count'] = isset($q['postid']) ? $blobs_count[$q['postid']] : 0;
		}
	}


/*
	Omit PHP closing tag to help avoid accidental output
*/