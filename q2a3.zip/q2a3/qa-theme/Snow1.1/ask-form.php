<div class= "col-sm-7 col-xs-12">
				<div class="form-group">
					<label>Your Question in one sentence:</label>
					<input type="text" class="form-control" placeholder="Type your question here...">
				</div>

				<div class="form-group">
					<label>Category:</label>
					<select class="form-control">
						<option>Select</option>
						<option>sample option 1</option>
						<option>option 2</option>
					</select>
				</div>

				<div class="form-group">
					<label>More information for the question:</label>
					<trix-editor angular-trix ng-model="quesDetails"></trix-editor>
				</div>

				<div class="form-group">
					<label>Preview:</label>
					<div class = "preview" ng-bind="quesDetails"></div>
				</div>

				<div class="form-group">
					<label>Tags:</label>
					<input type="text" class="form-control" placeholder="Type your tags here...">
					<small><i>Use hyphens to combine words.</i></small>
				</div>
				<hr/>
				<div class="form-group form-inline browse-file">
					<label class="visible-xs">Attach files:</label>
					
					<input type="file" class="form-control file-input" style="display:none;">
					<button class="btn btn-default btn-green hidden-xs" type="button">Attach files</button> &nbsp;
					<div class="input-group">
						<input type="input" class="form-control text-input" disabled="true">
						<div class="input-group-btn">
							<button class="btn btn-default btn-gray browse-btn" type="button">Browse</button>
						</div>
					</div>
					
				</div>
				<hr/>
				<div class="form-group">
					<input id="notify" type="checkbox"> 
					<label for="notify" style="display:flex;"><span><span></span></span>Email me if my question is answered or commented on</label>
				</div>
				<hr/>
				<div class="form-group centered ">
					<div class="robot-box">
						<input id="robot" type="checkbox"> 
						<label for="robot"><span><span></span></span>I am not a Robot</label>
					</div>
				</div>
				<hr/>
				<div class="form-group centered">
					<button class="btn btn-default btn-green" type="button">Post your question</button>
				</div>
