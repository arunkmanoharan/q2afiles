<?php

if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


function qa_users_sub_nimeyo_navigation()
/*
	Return the sub navigation structure for user listing pages
*/
	{
		if ((!QA_FINAL_EXTERNAL_USERS) && (qa_get_logged_in_level()>=QA_USER_LEVEL_MODERATOR)) {
			return array(
				'users/active' => array(
					'url' => qa_path_html('users/active'),
					'label' => 'ACTIVE',
				),
				'users/blocked' => array(
					'label' => 'INACTIVE',
					'url' => qa_path_html('users/blocked'),
				),
			);

		} else
			return null;
	}
	

	function qa_db_active_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight', 'loggedin'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags="0" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}
	
	function qa_db_inactive_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight','loggedin'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags!="0" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}

// CUSTOMISED FUNCTION FOR GETTING THE DATA IN THE RIGHT FORMAT ` MADHAV
	function qa_db_read_all_values_multiple_rows($result)
	{
		if (!($result instanceof mysqli_result))
			qa_fatal_error('Reading column from invalid result');

		$lable = array();
		$data = array();
		$output = array();
		while ($row = $result->fetch_row()){
			$lable[] = $row[0];
			$data[] = $row[1];
		}
		$output = array_combine($lable, $data);
		return $output;
	}