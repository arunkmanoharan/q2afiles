<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-page-dashboard.php
	Description: Controller for the dashboard page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

	if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
		header('Location: ../');
		exit;
	}
	

	require_once QA_INCLUDE_DIR.'db/selects.php';
	require_once QA_INCLUDE_DIR.'db/admin.php';
	require_once QA_INCLUDE_DIR.'qa-db.php';	
	require_once QA_INCLUDE_DIR.'app/format.php';
	require_once QA_PLUGIN_DIR.'nimeyo-custom/functions.php';
	

//	Prepare content for theme

	$qa_content = qa_content_prepare();
	
	$qa_content['dashboard_details'] = array(
		//Total number of view to any post
		"page_views_last_month" => qa_db_read_one_value(qa_db_query_sub('SELECT SUM(views) FROM ^posts')),
		// Total number of questions
		"questions" => qa_db_read_one_value(qa_db_query_sub("SELECT COUNT(postid) FROM ^posts where type = 'Q' ")),
		
		"responses" => qa_db_read_one_value(qa_db_query_sub("SELECT COUNT(postid) FROM ^posts where type = 'A' ")),
		
		'comments'=>qa_db_read_one_value(qa_db_query_sub("SELECT COUNT(postid) FROM ^posts where type = 'C' ")),
		//Used inbuilt function
		'users'=>qa_db_count_users(),
		// Taking max asnwers from each category
		'highest_answers'=>qa_db_read_one_value(qa_db_query_sub('SELECT sum(`acount`) FROM ^posts GROUP BY `categoryid` ORDER BY acount desc')),
		//Taking min asnwers from each category
		'lowest_anwers'=>qa_db_read_one_value(qa_db_query_sub('SELECT sum(`acount`) FROM ^posts GROUP BY `categoryid` ORDER BY acount ASC')),
		//Taking max questions from each category
		'highest_questions'=>qa_db_read_one_value(qa_db_query_sub('SELECT count(`title`) FROM `qa_posts` GROUP BY `categoryid` ORDER BY acount DESC')),
		//Taking min questions from each category
		'lowest_questions'=> qa_db_read_one_value(qa_db_query_sub('SELECT count(`title`) FROM `qa_posts` GROUP BY `categoryid` ORDER BY acount ASC')),
		'Harsh' => 'Infosys',
		
		
		); 
	
	
	
	return $qa_content;


/*
	Omit PHP closing tag to help avoid accidental output
*/