$(document).ready(function(){ // when the document is loaded completely
	
	$('#shrink-banner').on('click',function(){
		$('.blue-banner').toggleClass('shrink');
	});

	$('.browse-file .browse-btn, .browse-file .text-input').click(function () {
		$('.browse-file .file-input').click();
		
	});

	$('.browse-file .file-input').change(function(){
		console.log($('.browse-file .file-input').val().split('C:\\fakepath\\')[1]);
		$('.browse-file .text-input').val($('.browse-file .file-input').val().split('C:\\fakepath\\')[1]);
	});

	$('.as-select .select-default').on('click',function(){
		$(this).siblings('ul.option').toggle();
	});

	$('.blue-header.tags-page .arrow a').on('click',function(){
		$('.blue-header.tags-page').toggleClass('shrink');
	});

});