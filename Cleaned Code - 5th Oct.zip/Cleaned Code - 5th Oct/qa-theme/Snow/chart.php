<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.min.js"></script>		
<?php 
	require_once QA_INCLUDE_DIR.'db/selects.php';
	require_once QA_INCLUDE_DIR.'db/admin.php';
	require_once QA_INCLUDE_DIR.'qa-db.php';	
	require_once QA_INCLUDE_DIR.'app/format.php';
	
	// this function will take the userIds and return usernames in an array. 
	function get_username_by_userid($userids){
		$userNames = array();
		for($i = 0; $i < sizeof($userids); $i++){
			if($userids[$i] == null)
				array_push($userNames,'Visitor');
			else
				{
				$userName=qa_db_read_one_value(qa_db_query_sub('SELECT handle FROM ^users where userid = $',$userids[$i]));
				array_push($userNames,$userName);
				}
			}
		return $userNames;
	}
	
	
	//Number of categories
	$noOfCategories = qa_db_read_one_value(qa_db_query_sub('select count(*) from ^categories'));
	
	/* NUMBER OF POSTS BY CATEGORY/DL
		All categries
		category wise questions
		category wise Answers */
		
		$allCategories = qa_db_read_all_values(qa_db_query_sub('select title from ^categories'));
		$qestionsInCategory = qa_db_read_all_values(qa_db_query_sub('select qcount from ^categories'));
		$ansInCategory = qa_db_read_all_values(qa_db_query_sub("SELECT IFNULL(qa2.aswers,0) FROM qa_categories qc LEFT JOIN qa_posts qp ON(qp.categoryid = qc.categoryid AND qp.type='Q') LEFT JOIN (SELECT count(qa.postid) as aswers, qa.categoryid FROM qa_posts qa WHERE qa.type='A' GROUP BY qa.categoryid) qa2 ON (qa2.categoryid = qp.categoryid) GROUP BY qp.categoryid ORDER by qp.categoryid asc"));
		
	
	/* Number Of Messages In Each Category ( Yearly, Quarterly, Monthly,Weekly)
		category wise Answers+comments */
		
		//Weekly

		//Monthly
		$monthc1 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%U') FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$monthDatac1 = qa_db_read_all_values(qa_db_query_sub("SELECT COUNT(type) FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$monthCategoryc1 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		//Quarterly
		$quarterc1 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%U') FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$quarterDatac1 = qa_db_read_all_values(qa_db_query_sub("SELECT COUNT(type) FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$quarterCategoryc1 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		
		//Yearly
		$yearc1 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%U') FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$yearcDatac1 = qa_db_read_all_values(qa_db_query_sub("SELECT COUNT(type) FROM qa_posts WHERE type='C' OR type = 'A' GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$yearCategoryc1 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts WHERE type='C' OR type = 'A'  GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		
	
	/* Number Of Searches And Views Overtime ( Yearly, Quarterly, Monthly,Weekly)
		Views */
				
		//Weekly
		$weekc2 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%U') FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$weekDatac2 = qa_db_read_all_values(qa_db_query_sub("SELECT SUM(views) FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$weekCategoryc2 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		
		
		//Monthly
		$monthc2 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%M') FROM qa_posts GROUP BY DATE_FORMAT(created, '%M'),categoryid"));
		$monthDatac2 = qa_db_read_all_values(qa_db_query_sub("SELECT SUM(views) FROM qa_posts GROUP BY DATE_FORMAT(created, '%M'),categoryid"));
		$monthCategoryc2 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts GROUP BY DATE_FORMAT(created, '%M'),categoryid"));
		
		
		
		//Quarterly
		$quarterc2 = qa_db_read_all_values(qa_db_query_sub("SELECT Quarter(created) FROM qa_posts GROUP BY  Quarter(created),categoryid"));
		$quarterDatac2 = qa_db_read_all_values(qa_db_query_sub("SELECT SUM(views) FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$quarterCategoryc2 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		
		
		//Yearly
		$yearc2 = qa_db_read_all_values(qa_db_query_sub("SELECT DATE_FORMAT(created, '%U') FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$yearcDatac2 = qa_db_read_all_values(qa_db_query_sub("SELECT SUM(views) FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		$yearCategoryc2 = qa_db_read_all_values(qa_db_query_sub("SELECT categoryid FROM qa_posts GROUP BY DATE_FORMAT(created, '%U'),categoryid"));
		
		
		
	/* Number Of Logged Users ( Yearly, Quarterly, Monthly,Weekly)
		Total number of logged in users
		Increase (as compared to last - Yearly, Quarterly, Monthly,Weekly ) */
		
	/* TOP VISITORS
	Number Of Searches And Views made by visitors in each category
	limit people to 10 
	*/
	
	
	
	/* Most Active users 
	Top 10 users with the most points
		Show the number of questions and answers too
	*/
	
	$mostQuestionsCount = qa_db_read_all_values(qa_db_query_sub("SELECT count(qp.postid) FROM qa_users qc LEFT JOIN qa_posts qp ON(qp.userid = qc.userid AND qp.type='Q') LEFT JOIN ( SELECT count(qa.postid) as aswers, qa.userid FROM qa_posts qa WHERE qa.type='A' GROUP BY qa.userid) qa2 ON (qa2.userid = qp.userid) GROUP BY qp.userid ORDER BY count(qp.postid)+ifnull(qa2.aswers,0) DESC LIMIT 10"));
	$mostAnswersCount = qa_db_read_all_values(qa_db_query_sub("SELECT ifnull(qa2.aswers,0) FROM qa_users qc LEFT JOIN qa_posts qp ON(qp.userid = qc.userid AND qp.type='Q') LEFT JOIN ( SELECT count(qa.postid) as aswers, qa.userid FROM qa_posts qa WHERE qa.type='A' GROUP BY qa.userid) qa2 ON (qa2.userid = qp.userid) GROUP BY qp.userid ORDER BY count(qp.postid)+ifnull(qa2.aswers,0) DESC LIMIT 10"));
	$mostActiveUsers = qa_db_read_all_values(qa_db_query_sub("SELECT qc.handle FROM qa_users qc LEFT JOIN qa_posts qp ON(qp.userid = qc.userid AND qp.type='Q') LEFT JOIN ( SELECT count(qa.postid) as aswers, qa.userid FROM qa_posts qa WHERE qa.type='A' GROUP BY qa.userid) qa2 ON (qa2.userid = qp.userid) GROUP BY qp.userid ORDER BY count(qp.postid)+ifnull(qa2.aswers,0) DESC LIMIT 10"));
	
	
	
	/* Most responsive users
		The users with the most answers		
	*/
	$mostResponseCount = qa_db_read_all_values(qa_db_query_sub("select COUNT(postid),userid FROM qa_posts where type = 'A' group by userid ORDER BY COUNT(postid) DESC LIMIT 10"));
	$mostResponsiveUsers = get_username_by_userid(qa_db_read_all_values(qa_db_query_sub("select userid FROM qa_posts where type = 'A' group by userid ORDER BY COUNT(postid) DESC LIMIT 10")));
	

?>	
<script>
var ctx = document.getElementById("myChart");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($allCategories);?>,
        datasets: [{	
            label: 'First datasets',
			fillColor: "#FC9775",
            data: <?php echo json_encode($qestionsInCategory);?>,
			backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ]
			
			},
			{
        label: "My Second dataset",
        fillColor: "#5A69A6",
        data: <?php echo json_encode($ansInCategory);?>,
		backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ]
    }
			
            ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});


var ctx = document.getElementById("mostResponsiveUsers");
var myChart = new Chart(ctx, {
			  type: 'bar',
			  data: {
				labels: <?php echo json_encode($mostResponsiveUsers); ?>,
				datasets: [{
				  label: '# of Votes',
				  
				  data: <?php echo json_encode($mostResponseCount); ?>,
				  backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)'
				  ],
				  borderColor: [
					'rgba(255,99,132,1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)'
				  ],
				  borderWidth: 1
				}]
			  },
			  options: {
				scales: {
				  yAxes: [{
					ticks: {
					  beginAtZero: true
					}
				  }]
				}
			  }
			});


			

/* MOST ACTIVE USERS 
================================*/

var ctx = document.getElementById("mostActiveUsers");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($mostActiveUsers);?>,
        datasets: [{	
            label: 'First datasets',
			fillColor: "#FC9775",
            data: <?php echo json_encode($mostQuestionsCount);?>,
			backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ]
			
			},
			{
        label: "My Second dataset",
        fillColor: "#5A69A6",
        data: <?php echo json_encode($mostAnswersCount);?>,
		backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ]
    }
			
            ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
		
			


			
</script>
