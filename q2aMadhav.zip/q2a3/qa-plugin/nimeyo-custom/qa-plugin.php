<?php

/*
	Plugin Name: Nimeyo Custom
	Plugin URI:
	Plugin Description: Nimeyo Custom
	Plugin Version: 1.0.1
	Plugin Date: 2011-12-06
	Plugin Author: Question2Answer
	Plugin Author URI: 
	Plugin License: 
	Plugin Minimum Question2Answer Version: 1.4
	Plugin Update Check URI:
*/


if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


qa_register_plugin_overrides('qa-pages-override.php');

qa_register_plugin_module('widget', 'qa-activity-count.php', 'qa_nimeyo_activity_count', 'Nimeyo Activity Count');

